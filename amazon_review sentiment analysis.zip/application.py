import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
nltk.download('vader_lexicon')
sia = SentimentIntensityAnalyzer()
text1 = "I absolutely love this product! It is fantastic"
text2 = "They failed to meet the deadline."
text3 = "While the construction project is progressing according to schedule, several environmental concerns have been raised by local residents."
sentiment1 = sia.polarity_scores(text1)
sentiment2 = sia.polarity_scores(text2)
sentiment3 = sia.polarity_scores(text3)

print(f"Sentiment for text1: {sentiment1}")
print(f"Sentiment for text2: {sentiment2}")
print(f"Sentiment for text3: {sentiment3}")

import pandas as pd
df = pd.read_csv("D:/amazon_product_analysis/amazon_dataset.csv")
df
df.isnull().sum()
df.dropna()

from nltk.corpus import stopwords
nltk.download("stopwords")
stop_words = set(stopwords.words('english'))

import re
from nltk.tokenize import word_tokenize

def preprocess_text(text):
    text = re.sub(r'[^a-zA-Z\s]','',text,re.I | re.A)
    text = text.lower().strip()
    text = text.lower().strip()
    tokens = word_tokenize(text)
    tokens = [i for i in tokens if i not in stop_words]
    return ' '.join(tokens)
t = "ending the item takes a long time, the"
print(preprocess_text(t))

df ['Post_Text'] = df['Post_Text'].apply(preprocess_text)
df.head(3)
x = ['Post_Text']
y = df['Sentiment'].apply(lambda x:1 if x == 'Positive' else (0 if x =='Neutral' else -1))

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split

x = ["This is a sentence", "Another sentence here", "Yet another one"]
y = [1, 0, 1]
vectorizer = TfidfVectorizer(max_features=1000, ngram_range=(1,2))
x_vectorizer = vectorizer.fit_transform(x).toarray()
print(f"Length of x_vectorizer: {len(x_vectorizer)}")
print(f"Length of y: {len(y)}")
assert len(x_vectorizer) == len(y), "Feature and target arrays have different lengths!"

x_train, x_test, y_train, y_test = train_test_split(x_vectorizer, y, test_size=0.2, random_state=42)

from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

rf_model = RandomForestClassifier(n_estimators =200, random_state = 42)
rf_model.fit(x_train,y_train)
svm_model = SVC(kernel = "linear",random_state= 42)
svm_model.fit(x_train,y_train)
nb_model = MultinomialNB()
nb_model.fit(x_train,y_train)

def evaluate_models():
    models = {"Random Forest":rf_model, "SVM":svm_model,"Naive Bayes": nb_model}
    accuracy_results = {}
    for model_name, model in models.items():
        y_pred = model.predict(x_test)
        accuracy = accuracy_score(y_test, y_pred)
        accuracy_results[model_name] = accuracy
        print(f"\n{model_name}:\nAccuracy: {accuracy}\n")
        print(classification_report(y_test,y_pred))
    return accuracy_results
ev = evaluate_models()
print("\n".join([f"{model}:{accuracy:.2f}" for model, accuracy in ev.items()]))

review = input("Enter your review")
preprocess_review = preprocess_text(review)
review_vector = vectorizer.transform([preprocess_review]).toarray()
prediction = svm_model.predict(review_vector)
sentiment_mapping = {1:"Postive", 0:"Neutral", -1:"Negative"}
sentiment = sentiment_mapping[prediction[0]]
print(f"Customer share {sentiment} review about the product.")