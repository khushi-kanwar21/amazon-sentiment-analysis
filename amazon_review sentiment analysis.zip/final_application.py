import tkinter as tk
from tkinter import messagebox
import pandas as pd
import re
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
import nltk

nltk.download('stopwords')
nltk.download('punkt')

df = pd.read_csv("D:/amazon_product_analysis/amazon_dataset.csv")
df.dropna(inplace=True)

stop_words = set(stopwords.words('english'))

def preprocess_text(text):
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    text = text.lower().strip()
    tokens = word_tokenize(text)
    tokens = [i for i in tokens if i not in stop_words]
    return ' '.join(tokens)

vectorizer = TfidfVectorizer(max_features=1000, ngram_range=(1, 2))
X = vectorizer.fit_transform(df['Post_Text']).toarray()
y = df['Sentiment'].apply(lambda x: 1 if x == 'Positive' else (0 if x == 'Neutral' else -1))

svm_model = SVC(kernel="linear", random_state=42)
svm_model.fit(X, y)

def predict_sentiment():
    review = review_entry.get("1.0", tk.END).strip()
    if not review:
        messagebox.showwarning("Input Error", "Please enter a review.")
        return
    
    preprocessed_review = preprocess_text(review)
    review_vector = vectorizer.transform([preprocessed_review]).toarray()
    prediction = svm_model.predict(review_vector)
    
    sentiment_mapping = {1: "Positive", 0: "Neutral", -1: "Negative"}
    sentiment = sentiment_mapping.get(prediction[0], "Unknown")
    messagebox.showinfo("Prediction Result", f"The sentiment of the review is: {sentiment}")

root = tk.Tk()
root.title("Sentiment Analysis Tool")

review_entry = tk.Text(root, height=10, width=50)
review_entry.pack(pady=20)

predict_button = tk.Button(root, text="Predict Sentiment", command=predict_sentiment)
predict_button.pack(pady=10)

# Start the GUI loop
root.mainloop()
